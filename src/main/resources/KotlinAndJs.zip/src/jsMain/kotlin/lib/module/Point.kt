package lib.module

@JsName("Point")
external interface Point {
    val x: Int
    val y: Int
}
