declare function back(): boolean;

declare function home(): boolean;

declare function powerDialog(): boolean;

declare function notifications(): boolean;

declare function quickSettings(): boolean;

declare function recents(): boolean;

declare function splitScreen(): boolean;

declare function Home(): void;

declare function Back(): void;

declare function Power(): void;

declare function Menu(): void;

declare function VolumeUp(): void;

declare function VolumeDown(): void;

declare function Camera(): void;

declare function Up(): void;

declare function Down(): void;

declare function Left(): void;

declare function Right(): void;

declare function OK(): void;

declare function Text(text: string): void;

/**
 * 模拟物理按键。
 * @param code 要按下的按键的数字代码或名称。 代码请参考 @see KeyCodeValue
 *
 */
declare function KeyCode(code: number | string): void;

declare namespace KeyCodeValue {
    const KEYCODE_MENU = 1
    const KEYCODE_SOFT_RIGHT = 2
    const KEYCODE_HOME = 3
    const KEYCODE_BACK = 4
    const KEYCODE_CALL = 5
    const KEYCODE_ENDCALL = 6
    const KEYCODE_0 = 7
    const KEYCODE_1 = 8
    const KEYCODE_2 = 9
    const KEYCODE_3 = 10
    const KEYCODE_4 = 11
    const KEYCODE_5 = 12
    const KEYCODE_6 = 13
    const KEYCODE_7 = 14
    const KEYCODE_8 = 15
    const KEYCODE_9 = 16
    const KEYCODE_STAR = 17
    const KEYCODE_POUND = 18
    const KEYCODE_DPAD_UP = 19
    const KEYCODE_DPAD_DOWN = 20
    const KEYCODE_DPAD_LEFT = 21
    const KEYCODE_DPAD_RIGHT = 22
    const KEYCODE_DPAD_CENTER = 23
    const KEYCODE_VOLUME_UP = 24
    const KEYCODE_VOLUME_DOWN = 25
    const KEYCODE_POWER = 26
    const KEYCODE_CAMERA = 27
    const KEYCODE_CLEAR = 28
    const KEYCODE_A = 29
    const KEYCODE_B = 30
    const KEYCODE_C = 31
    const KEYCODE_D = 32
    const KEYCODE_E = 33
    const KEYCODE_F = 34
    const KEYCODE_G = 35
    const KEYCODE_H = 36
    const KEYCODE_I = 37
    const KEYCODE_J = 38
    const KEYCODE_K = 39
    const KEYCODE_L = 40
    const KEYCODE_M = 41
    const KEYCODE_N = 42
    const KEYCODE_O = 43
    const KEYCODE_P = 44
    const KEYCODE_Q = 45
    const KEYCODE_R = 46
    const KEYCODE_S = 47
    const KEYCODE_T = 48
    const KEYCODE_U = 49
    const KEYCODE_V = 50
    const KEYCODE_W = 51
    const KEYCODE_X = 52
    const KEYCODE_Y = 53
    const KEYCODE_Z = 54
    const KEYCODE_COMMA = 55
    const KEYCODE_PERIOD = 56
    const KEYCODE_ALT_LEFT = 57
    const KEYCODE_ALT_RIGHT = 58
    const KEYCODE_SHIFT_LEFT = 59
    const KEYCODE_SHIFT_RIGHT = 60
    const KEYCODE_TAB = 61
    const KEYCODE_SPACE = 62
    const KEYCODE_SYM = 63
    const KEYCODE_EXPLORER = 64
    const KEYCODE_ENVELOPE = 65
    const KEYCODE_ENTER = 66
    const KEYCODE_DEL = 67
    const KEYCODE_GRAVE = 68
    const KEYCODE_MINUS = 69
    const KEYCODE_EQUALS = 70
    const KEYCODE_LEFT_BRACKET = 71
    const KEYCODE_RIGHT_BRACKET = 72
    const KEYCODE_BACKSLASH = 73
    const KEYCODE_SEMICOLON = 74
    const KEYCODE_APOSTROPHE = 75
    const KEYCODE_SLASH = 76
    const KEYCODE_AT = 77
    const KEYCODE_NUM = 78
    const KEYCODE_HEADSETHOOK = 79
    const KEYCODE_FOCUS = 80
    const KEYCODE_PLUS = 81
    const KEYCODE_MENU_V2 = 82
    const KEYCODE_NOTIFICATION = 83
    const KEYCODE_SEARCH = 84
    const TAG_LAST_KEYCODE = 85

}
