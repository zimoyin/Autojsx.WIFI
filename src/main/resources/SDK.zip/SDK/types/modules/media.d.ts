declare namespace media {
    /**
     * 把图片加入相册
     * @param path
     */
    function scanFile(path: string): void;

    /**
     * 播放音乐
     * @param path 音乐文件路径
     * @param volume  播放音量，为0~1的浮点数，默认为1
     * @param looping 是否循环播放，如果looping为true则循环播放，默认为false
     */
    function playMusic(path: string, volume?: number, looping?: boolean);

    /**
     * 把当前播放进度调整到时间msec的位置。如果当前没有在播放音乐，则调用函数没有任何效果。
     * @param msec 表示音乐进度
     */
    function musicSeekTo(msec: number): void;

    /**
     * 暂停音乐播放。如果当前没有在播放音乐，则调用函数没有任何效果。
     */
    function pauseMusic(): void;

    /**
     * 继续音乐播放。如果当前没有播放过音乐，则调用该函数没有任何效果。
     */
    function resumeMusic(): void;

    /**
     * 停止音乐播放。如果当前没有在播放音乐，则调用函数没有任何效果。
     */
    function stopMusic(): void;

    /**
     * 返回当前是否正在播放音乐。
     */
    function isMusicPlaying(): boolean;

    /**
     * 返回当前音乐的时长。单位毫秒。
     */
    function getMusicDuration(): number;

    /**
     * 返回当前音乐的播放进度(已经播放的时间)，单位毫秒。
     */
    function getMusicCurrentPosition(): number;
}
