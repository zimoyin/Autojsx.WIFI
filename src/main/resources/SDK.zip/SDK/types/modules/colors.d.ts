declare namespace colors {
    /**
     * 返回颜色值的字符串，格式为 "#AARRGGBB"。
     *  @param color 颜色值
     */
    function toString(color: number): string;

    /**
     * 返回颜色color的R通道的值，范围0~255.
     *  @param color 颜色值
     */
    function red(color: number | string): number;

    /**
     * 返回颜色color的G通道的值，范围0~255.
     *  @param color 颜色值
     */
    function green(color: number | string): number;

    /**
     * 返回颜色color的B通道的值，范围0~255.
     *  @param color 颜色值
     */
    function blue(color: number | string): number;

    /**
     * 返回颜色color的Alpha通道的值，范围0~255.
     *  @param color 颜色值
     */
    function alpha(color: number | string): number;

    /**
     * 返回这些颜色通道构成的整数颜色值。Alpha通道将是255（不透明）。
     * @param red  颜色的R通道的值
     * @param green  颜色的G通道的值
     * @param blue  颜色的B通道的值
     */
    function rgb(red: number, green: number, blue: number): number;

    /**
     * 返回这些颜色通道构成的整数颜色值。
     * @param alpha 该颜色通道值
     * @param red 该颜色通道值
     * @param green 该颜色通道值
     * @param blue 该颜色通道值
     */
    function argb(alpha: number, red: number, green: number, blue: number): number;

    /**
     * 返回颜色的整数值。
     * @param colorStr 表示颜色的字符串，例如"#112233"
     */
    function parseColor(colorStr: string): number;

    /**
     * 返回两个颜色是否相似。
     * @param color1
     * @param color2
     * @param threshold 颜色相似度临界值，默认为4。取值范围为0~255。这个值越大表示允许的相似程度越小，如果这个值为0，则两个颜色相等时该函数才会返回true。
     * @param algorithm 颜色匹配算法，默认为"diff"
     *  "diff": 差值匹配。与给定颜色的R、G、B差的绝对值之和小于threshold时匹配。
     *  "rgb": rgb欧拉距离相似度。与给定颜色color的rgb欧拉距离小于等于threshold时匹配。
     *  "rgb+": 加权rgb欧拉距离匹配(LAB Delta E)。
     *  "hs": hs欧拉距离匹配。hs为HSV空间的色调值。
     */
    function isSimilar(color1: number | string, color2: number | string, threshold: number, algorithm: 'diff' | 'rgb' | 'rgb+' | 'hs'): boolean;

    /**
     * 返回两个颜色是否相等。*注意该函数会忽略Alpha通道的值进行比较。
     * @param color1
     * @param color2
     */
    function equals(color1: number | string, color2: number | string): boolean;

    /**
     * 黑色，颜色值 #FF000000
     */
    const BLACK;
    /**
     * 深灰色，颜色值 #FF444444
     */
    const DKGRAY;
    /**
     * 灰色，颜色值 #FF888888
     */
    const GRAY;
    /**
     * 亮灰色，颜色值 #FFCCCCCC
     */
    const LTGRAY;
    /**
     * 白色，颜色值 #FFFFFFFF
     */
    const WHITE;
    /**
     * 红色，颜色值 #FFFF0000
     */
    const RED;
    /**
     * 绿色，颜色值 #FF00FF00
     */
    const GREEN;
    /**
     * 蓝色，颜色值 #FF0000FF
     */
    const BLUE;
    /**
     * 黄色，颜色值 #FFFFFF00
     */
    const YELLOW;
    /**
     * 青色，颜色值 #FF00FFFF
     */
    const CYAN;
    /**
     * 品红色，颜色值 #FFFF00FF
     */
    const MAGENTA;
    /**
     * 透明，颜色值 #00000000
     */
    const TRANSPARENT;
}

