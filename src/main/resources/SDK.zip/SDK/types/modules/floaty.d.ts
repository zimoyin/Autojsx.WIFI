declare namespace floaty {
    /**
     * 返回当前应用是否有悬浮窗权限。（不会触发请求权限操作）
     */
    function checkPermission(): boolean;

    /**
     * 跳转到系统的悬浮窗权限请求界面。
     */
    function requestPermission(): void;

    /**
     * 指定悬浮窗的布局，创建并显示一个悬浮窗，返回一个FloatyWindow对象。
     * 该悬浮窗自带关闭、调整大小、调整位置按键，可根据需要调用setAdjustEnabled()函数来显示或隐藏。
     * 其中layout参数可以是xml布局或者一个View，更多信息参见ui模块的说明。
     * @param layout 悬浮窗界面的传入XML或者View
     * @return FloatyWindow 悬浮窗对象
     */
    function window(layout: any): FloatyWindow;

    /**
     * 指定悬浮窗的布局，创建并显示一个原始悬浮窗，返回一个FloatyRawWindow对象。
     * 与floaty.window()函数不同的是，该悬浮窗不会增加任何额外设施（例如调整大小、位置按钮），您可以根据自己需要编写任何布局。
     * 而且，该悬浮窗支持完全全屏，可以覆盖状态栏，因此可以做护眼模式之类的应用。
     * @param layout
     * @return FloatyWindow 悬浮窗对象
     */
    function rawWindow(layout: any): FloatyRawWindow;

    /**
     * 关闭所有本脚本的悬浮窗。
     */
    function closeAll(): void;

    /**
     * 悬浮窗对象，可通过FloatyWindow.{id} 获取悬浮窗界面上的元素。
     * 例如, 悬浮窗window上一个控件的id为aaa, 那么window.aaa即可获取到该控件，类似于ui。
     */
    interface FloatyWindow {
        /**
         * 是否启用悬浮窗调整(大小、位置)
         * @param enabled
         */
        setAdjustEnabled(enabled: boolean): void;

        setPosition(x: number, y: number): void;

        getX(): number;

        getY(): number;

        setSize(width: number, height: number): void;

        getWidht(): number;

        getHeight(): number;

        /**
         * 关闭悬浮窗。如果悬浮窗已经是关闭状态，则此函数将不执行任何操作。
         */
        close(): void;

        /**
         * 使悬浮窗被关闭时自动结束脚本运行。
         */
        exitOnClose(): void;
    }

    /**
     * 原始悬浮窗对象，window.{id} 获取悬浮窗界面上的元素。
     * 例如, 悬浮窗window上一个控件的id为aaa, 那么window.aaa即可获取到该控件，类似于ui。
     */
    interface FloatyRawWindow {
        /**
         * 是否启用悬浮窗调整(大小、位置)
         * @param enabled
         */
        setAdjustEnabled(enabled: boolean): void;

        /**
         * 设置悬浮窗是否可触摸，如果为true, 则悬浮窗将接收到触摸、点击等事件并且无法继续传递到悬浮窗下面；
         * 如果为false, 悬浮窗上的触摸、点击等事件将被直接传递到悬浮窗下面。
         * 处于安全考虑，被悬浮窗接收的触摸事情无法再继续传递到下层。
         * @param touchable 是否可触摸
         */
        setTouchable(touchable:boolean):void;

        setPosition(x: number, y: number): void;

        getX(): number;

        getY(): number;

        setSize(width: number, height: number): void;

        getWidht(): number;

        getHeight(): number;

        /**
         * 关闭悬浮窗。如果悬浮窗已经是关闭状态，则此函数将不执行任何操作。
         */
        close(): void;

        /**
         * 使悬浮窗被关闭时自动结束脚本运行。
         */
        exitOnClose(): void;
    }
}
