declare namespace zips {
    /**
     * 压缩
     * @param type 压缩类型，请使用 zips.TYPE_ZIP 等 来确定。支持的类型：zip 7z bz2 bzip2 tbz2 tbz gz gzip tgz tar wim swm xz txz。
     * @param filePath 压缩文件路径(必须是完整路径)
     * @param dirPath 目录路径(必须是完整路径)
     * @param password 压缩密码
     * @return number 你可以通过  zip.REQUEST_SUCCESS 等来确定返回值信息代表类型
     */
    function A(type: string, filePath: string, dirPath: string, password: string): number

    /**
     * 解压
     * @param filePath 压缩文件路径(必须是完整路径)
     * @param dirPath 目录路径(必须是完整路径)
     * @param password 压缩密码
     * @return number 你可以通过 zip.REQUEST_SUCCESS 等 来确定返回值信息代表类型
     */
    function X(filePath: string, dirPath: string, password: string): number


    const TYPE_ZIP = "zip"
    const TYPE_7z = "7z"
    const TYPE_BZ2 = "bz2"
    const TYPE_BZIP2 = "bzip2"
    const TYPE_TBZ = "tbz"
    const TYPE_GZ = "gz"
    const TYPE_GZIP = "gzip"
    const TYPE_TGZ = "tgz"
    const TYPE_TAR = "tar"
    const TYPE_WIM = "wim"
    const TYPE_SWM = "swm"
    const TYPE_XZ = "xz"
    const TYPE_TXZ = "txz"


    /**
     * 压缩成功
     */
    const REQUEST_SUCCESS = 0
    /**
     * 压缩结束，存在非致命错误（例如某些文件正在被使用，没有被压缩）
     */
    const REQUEST_ERROR_EXCEPTION_EXIT = 1
    /**
     * 致命错误
     */
    const REQUEST_FATAL_ERROR_EXIT = 2
    /**
     * 命令行错误
     */
    const REQUEST_ERROR_SHALL = 7
    /**
     * 没有足够内存
     */
    const REQUEST_ERROR_NO_MEMORY = 8
    /**
     * 用户中止操作
     */
    const REQUEST_SUCCESS_USER_TERMINATION = 255
}
