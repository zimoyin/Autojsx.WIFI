interface Storage {
    get<T>(key: string, defaultValue?: T): T;
    put<T>(key: string, value: T): void;
    remove(key: string): void;
    contains(key: string): boolean;
    clear(): void;
}

declare namespace storages {
    /**
     * 创建一个本地存储并返回一个Storage对象。不同名称的本地存储的数据是隔开的，而相同名称的本地存储的数据是共享的。
     * @param name 本地存储名称
     */
    function create(name: string): Storage;

    /**
     * 删除一个本地存储以及他的全部数据。如果该存储不存在，返回false；否则返回true。
     * @param name 本地存储名称
     */
    function remove(name: string): boolean;
}