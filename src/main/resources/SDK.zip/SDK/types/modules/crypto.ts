declare namespace $crypto {
    /**
     * 加密
     * @param message 未加密字符串
     * @param key 密钥，注意：AES等算法要求KEY的长度是16位的倍数。例如 new $crypto.Key("password12345678");
     * @param type 加密类型
     */
    function encrypt(message: string, key: CryptoKey, type: string): Array<number>

    /**
     * 解密
     * @param message 加密后二进制数据
     * @param key 密钥，注意：AES等算法要求KEY的长度是16位的倍数。例如 new $crypto.Key("password12345678");
     * @param type 加密类型
     * @param output 输出类型 如： { output: 'string' }
     * @private
     */
    function decrypt(message: Array<number>, key: CryptoKey, type: string, output: { output: 'string' }): any
}

