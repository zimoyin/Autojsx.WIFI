declare function importPackage(val0:string)
declare function importClass(val0:string)

declare namespace  runtime{
    /**
     * 导入的jar必须 JDK <=6
     * @param val0
     */
    function loadJar(val0:string)
    /**
     * 导入的dex必须 JDK <=8
     * @param val0
     */
    function loadDex(val0:string)

    /**
     * 动态申请安卓的权限
     * @param val0
     */
    function requestPermissions(val0:Array<string>)
}