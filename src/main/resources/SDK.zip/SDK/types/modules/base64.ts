declare namespace $base64{
    /**
     * 编码
     * @param str
     */
    function encode(str: string): string

    /**
     * 解码
     * @param str
     */
    function decode(str: string): string
}